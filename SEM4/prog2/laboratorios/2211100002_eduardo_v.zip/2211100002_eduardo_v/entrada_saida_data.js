let data = prompt("Data: ")

let dataList = data.split("/")

console.log(dataList[1] + "/" + dataList[0] + "/" + dataList[2])
console.log(dataList[2] + "/" + dataList[1] + "/" + dataList[0])
console.log(dataList[0] + "-" + dataList[1] + "-" + dataList[2])


